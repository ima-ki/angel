# VIZORA site + admin (no dependencies)

1. Install Node.js 18+ (nodejs.org)
2. In this folder run:  node server.js
3. Site:  http://localhost:3000     Admin: http://localhost:3000/admin
4. Default password: admin123  → change it in Admin → Settings (or start with ADMIN_PASSWORD=yourpass node server.js the first time)

## Free AI
- Articles: Settings → provider. "pollinations" needs no key. gemini / groq / openrouter have free keys. ollama is 100% free on your own PC.
- 3D models: free Tripo account → API key → Settings. Or upload any .glb you made elsewhere.

## Put it online
Needs a host that runs Node (Render, Railway, Fly.io, a VPS). Keep the data/ and uploads/ folders on a persistent disk.
Put it behind HTTPS (the host usually does this). Content lives in data/*.json — back it up.

## v2 additions
- **Videos**: Admin → Videos → upload .mp4/.webm. They appear in a "Showreel" section on the site (streaming/seek supported).
- **SEO**: automatic /sitemap.xml, /robots.txt, /feed.xml (RSS); every article has a canonical link, Open Graph/Twitter tags and BlogPosting JSON-LD; the home page has Organization/WebSite JSON-LD. The admin is set to noindex.
- **AI articles are written for search**: main keyword in title + first paragraph, useful subheadings, meta-description excerpt.
- After going live: Admin → Settings → set your public website address, then add the site in Google Search Console and submit https://yourdomain/sitemap.xml.
- Hosting: needs Node (Render, Railway, Fly.io, VPS) with a persistent disk for data/ and uploads/. It cannot run on Hatchable (static hosting).
